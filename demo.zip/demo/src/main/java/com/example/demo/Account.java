package com.example.demo;

public class Account {

    private Number account_number;
    private Number pin;
    private double opening_balance; 
    private double overdraft;
    public Number getAccount_number() {
        return account_number;
    }
    public void setAccount_number(Number account_number) {
        this.account_number = account_number;
    }
    public Number getPin() {
        return pin;
    }
    public void setPin(Number pin) {
        this.pin = pin;
    }
    public double getOpening_balance() {
        return opening_balance;
    }
    public void setOpening_balance(double d) {
        this.opening_balance = d;
    }
    public double getOverdraft() {
        return overdraft;
    }
    public void setOverdraft(double d) {
        this.overdraft = d;
    }

    
}
