package com.example.demo;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.json.simple.JSONObject;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Main ATM class which provides APIs for
 * getting the available balance
 * withdraw the amount from the available balance 
 */
@SpringBootApplication
@RestController
public class MyATM {

    private List<Account> accounts = new ArrayList<Account>();
    public MyATM() {
        // Initializing of account, end to end solution has to read the data from DB
        Account account = new Account();
        account.setAccount_number(123456789);
        account.setPin(1234);
        account.setOpening_balance(800.00);
        account.setOverdraft(200.00);

        Account account1 = new Account();
        account1.setAccount_number(987654321);
        account1.setPin(4321);
        account1.setOpening_balance(1230);
        account1.setOverdraft(150);
        accounts.add(account);
        accounts.add(account1);
    }

  /**
   * Get the available balance for the given PIN 
   * @param pin
   * @return
   */
  @RequestMapping("/Mybank/Myatm/getBalance")
  public JSONObject getBalance(@RequestParam Number pin) {
    JSONObject response = new JSONObject();
    for(int i=0;i<accounts.size();i++) {
        Account account = accounts.get(i);
        if(account.getPin().equals(pin.intValue())) {
            response.put("Account number", account.getAccount_number());
            response.put("Balance " ,account.getOpening_balance());
            return response;
        }
    }
    return (JSONObject) response.put("Error", "Invalid Pin");
  }


  /**
   * Withdrawal API fetches the amount if there is sufficent balance and with valid pin
   * Ideally this API can be considered for the POST as well as we perform a update operation, 
   * but current implemented as get API
   * @param amount
   * @return
   */
  @RequestMapping("/Mybank/Myatm/withdraw")
  public JSONObject withdraw(@RequestParam Integer pin, @RequestParam Integer amount) {
    JSONObject response = new JSONObject();
    Map<Integer, Integer> withdrawalBalance = new HashMap<Integer, Integer>();
    for(int i=0;i<accounts.size();i++) {
        Account account = accounts.get(i);
        if(account.getPin().equals(pin)) {
            if(amount < account.getOpening_balance()){
                withdrawalBalance = getNotes(amount);
                response.put("Withdrawal amount", Integer.toString(amount));
                response.put("Remaing balance", account.getOpening_balance() - amount);
                response.put("denominations", withdrawalBalance);
                return response;

            } else {
                response.put("error", "Insfficient Balance");
                return response;
            }
        } 
    }
    return (JSONObject) response.put("error", "Insfficient Balance");
  }


/**
 * Utility API to get the Denominations for the given amount and the amount is represented in 
 * 50, 20, 10 and 5 formats and the order in which the precedence is taken from highest to lowest
 * @param amount
 * @return
 */
public Map<Integer, Integer>  getNotes(int amount) {

    int[] deno = {50,20,10,5};
    Map<Integer, Integer> currencies = new HashMap<Integer, Integer>(); 
    for (int i=0;i<deno.length;i++) {
        if(amount != 0) {
            int note = amount / deno[i];
            if(note != 0) {
                currencies.put(deno[i], note);
                amount = amount % deno[i];
            }
        } 
    }
    return currencies;
  }

  /**
   * The main application initialize the account and start the Spring boot application 
   * @param args
   */
  public static void main(String[] args) {
    SpringApplication.run(MyATM.class, args);
  }
}